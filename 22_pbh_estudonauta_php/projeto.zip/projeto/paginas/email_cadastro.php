<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

$mail = new PHPMailer;

$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'seu email';
$mail->Password = 'sua senha';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$mail->setFrom('seu email', 'Seu Delivery');


$mail->addAddress($email);
$mail->isHTML(true);
$mail->Subject = 'Confirmar Cadastro';

$link = "http://localhost/projeto/paginas/confirmar_cadastro.php?id=" . $idSegura;
$mensagem = "Olá. Você acabou de se cadastrar em nosso site. Por favor copie cole o link abaixo no seu navegador para confirmar seu cadastro: <br>" . $link;

$textoCorpo = '<h3>' . $nome . '</h3>';
$textoCorpo .= '<p>' . utf8_decode($email) . '</p>';
$textoCorpo .= '<p>' . utf8_decode($mensagem) . '</p>';
$mail->Body = $textoCorpo;

if (!$mail->send()) {
    echo 'Erro ao enviar email: ' . $mail->ErrorInfo;
} else {
    echo 'Mensagem Enviada.';
}
