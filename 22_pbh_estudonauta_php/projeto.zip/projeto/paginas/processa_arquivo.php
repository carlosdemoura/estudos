<?php

$pasta = 'uploads/';

if (move_uploaded_file($_FILES['arquivo']['tmp_name'], $pasta . $_FILES['arquivo']['name'])) {
    echo "Upload efetuado com sucesso!";
}
