<!DOCTYPE html>
<html lang="pt-br">

<head>
	<title>Carrinho</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../css/estilos.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
	<link rel="icon" href="../img/logo.png" type="image/gif">
</head>

<body>
	<!-- Logo -->
	<img src="../img/logo.png" class="logo">
	<ul class="menu">
		<li class="menu"><a href="../index.html">Home</a></li>
		<li class="menu"><a href="contato.html">Contato</a></li>
		<li class="menu"><a href="sobre-nos.html">Sobre Nós</a></li>
		<li class="menu"><a href="trabalhe-conosco.html">Trabalhe Conosco</a></li>
		<li class="menu"><a href="registrar.html">Registrar</a></li>
		<li class="menu"><a href="entrar.html">Entrar</a></li>
		<li class="menu"><a href="dicas.html">Dicas</a></li>
	</ul>
	<div><a href="carrinho.html"><img src="../img/carrinho.png" class="carrinho"></a></div>
	<h1 class="titulo-carrinho">MEU CARRINHO</h1>
	<?php
	$quantidade = $_GET['quantidade'];

	if ($quantidade > 0)
		echo $quantidade;
	else
		echo '<p class="texto-carrinho">Seu carrinho está vazio <br>:(</p>';
	?>

	<form name="formulario-carrinho" class="formulario-carrinho">
		<input type="text" placeholder="Ex: 12345-678" maxlength="8">
		<input type="submit" value="Calcular Frete" class="formulario-carrinho-calcular-frete"><a class="nao-sei-cep" href="http://www.buscacep.correios.com.br/sistemas/buscacep/"> Não sei meu cep</a><br><br>
		<input type="submit" value="Continuar" class="formulario-carrinho-continuar">
	</form>
	<a href="https://www.facebook.com/"><img src="../img/face.png" class="face"></a>
	<a href="https://www.instagram.com/"><img src="../img/insta.png" class="insta"></a>
	<a href="https://web.whatsapp.com/"><img src="../img/zap.png" class="zap"></a>
	<footer class="rodape">
		<p>© 2020 Seu Delivery - Todos os direitos reservados.</p>
	</footer>
</body>

</html>