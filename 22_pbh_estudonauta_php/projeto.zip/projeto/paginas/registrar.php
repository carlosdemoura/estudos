<?php
require('conexaoBD.php');

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['password'];

$senhaCripto = password_hash($senha, PASSWORD_DEFAULT);

$select = "SELECT email FROM clientes WHERE email = '$email'";
$consulta_select = mysqli_query($conexao, $select);
$arranjo = mysqli_fetch_array($consulta_select);
$arranjo_email = $arranjo['email'];


if ($arranjo_email == $email)
  echo "Esse login já existe.";
else {
  $insert = "INSERT INTO clientes (nome, email, usuario, senha)
  VALUES ('$nome', '$email', '$email', '$senhaCripto')";

  if ($conexao->query($insert) === TRUE) {
    $id = mysqli_insert_id($conexao);
    $idSegura = md5($id);
    echo "Dados gravados com sucesso.";
    require('email_cadastro.php');
  } else {
    echo "Erro: " . $sql . "<br>" . $conexao->error;
  }
}
$conexao->close();
