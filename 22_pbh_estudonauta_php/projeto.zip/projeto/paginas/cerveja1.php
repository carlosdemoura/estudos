<!DOCTYPE html>
<html lang="pt-br">

<head>
  <title>Cervejas</title>
  <meta charset="UTF-8" />
  <link rel="stylesheet" type="text/css" href="../css/estilos.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css" />
  <link rel="icon" href="../img/logo.png" type="image/gif" />
</head>

<body>
  <!-- Logo -->
  <img src="../img/logo.png" class="logo" />
  <ul class="menu">
    <li class="menu"><a href="../index.html">Home</a></li>
    <li class="menu"><a href="contato.html">Contato</a></li>
    <li class="menu"><a href="sobre-nos.html">Sobre Nós</a></li>
    <li class="menu"><a href="trabalhe-conosco.html">Trabalhe Conosco</a></li>
    <li class="menu"><a href="registrar.html">Registrar</a></li>
    <li class="menu"><a href="entrar.html">Entrar</a></li>
    <li class="menu"><a href="dicas.html">Dicas</a></li>
  </ul>
  <div>
    <a href="carrinho.html"><img src="../img/carrinho.png" class="carrinho" /></a>
  </div>
  <a href="marca1.html"><img src="../img/cerveja1.png" class="cerveja1-imagem" /></a>
  <h2 class="titulo-cervejas">Cerveja 1 600ml | garrafa inclusa</h2>
  <p class="texto-cervejas">R$7,99</p>
  <form name="formulario-cervejas" class="formulario-cervejas" method="GET" action="carrinho.php">
    <input type="number" id="quantidade" name="quantidade" value="7,99" /><br /><br />
    <input type="submit" value="Adicionar ao Carrinho" />
  </form>
  <a href="https://www.facebook.com/"><img src="../img/face.png" class="face" /></a>
  <a href="https://www.instagram.com/"><img src="../img/insta.png" class="insta" /></a>
  <a href="https://web.whatsapp.com/"><img src="../img/zap.png" class="zap" /></a>
  <footer class="rodape">
    <p>© 2020 Seu Delivery - Todos os direitos reservados.</p>
  </footer>
</body>

</html>