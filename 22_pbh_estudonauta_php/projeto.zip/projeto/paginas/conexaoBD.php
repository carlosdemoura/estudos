<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$bd = "seudeliverybd";

//Criando a conexão
$conexao = new mysqli($servidor, $usuario, $senha, $bd);
