<?php

session_start();
require('conexaoBD.php');

$usuario = $_POST['email'];
$senha = $_POST['password'];


$consulta = "SELECT clienteID, email, senha FROM clientes WHERE email = '$usuario'";

$acesso = mysqli_query($conexao, $consulta);
$informacao = mysqli_fetch_assoc($acesso);

$arranjoSenha = $informacao['senha'];
$arranjoUsuario = $informacao['email'];

if (!$acesso) {
    die("Falha na comunicação com o Banco de dados.");
    echo "<META HTTP-EQUIV='Refresh' CONTENT='3;URL=../index.html'>";
} elseif ((password_verify($senha, $arranjoSenha)) && ($arranjoUsuario == $usuario)) {
    $_SESSION["usuario_verificado"] = $informacao["clienteID"];
    echo "Login efetuado com sucesso";
    echo "<META HTTP-EQUIV='Refresh' CONTENT='3;URL=../index.html'>";
} else {
    echo "Usuário ou senha incorretos.";
    echo "<META HTTP-EQUIV='Refresh' CONTENT='3;URL=../index.html'>";
}
