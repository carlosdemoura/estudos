<?php session_start() ?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
	<title>Contato</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/estilos.css">
	<link rel="icon" href="../img/logo.png" type="image/gif">
</head>

<body>
	<!-- Logo -->
	<img src="../img/logo.png" class="logo">
	<ul class="menu">
		<li class="menu"><a href="../index.html">Home</a></li>
		<li class="menu"><a href="contato.html">Contato</a></li>
		<li class="menu"><a href="sobre-nos.html">Sobre Nós</a></li>
		<li class="menu"><a href="trabalhe-conosco.html">Trabalhe Conosco</a></li>
		<li class="menu"><a href="registrar.html">Registrar</a></li>
		<li class="menu"><a href="entrar.html">Entrar</a></li>
		<li class="menu"><a href="dicas.html">Dicas</a></li>
	</ul>
	<div><a href="carrinho.html"><img src="../img/carrinho.png" class="carrinho"></a></div>


	<?php


	if (isset($_SESSION['usuario_verificado'])) {
		include('tabelaDicas.php');
	} else
		echo "Você precisa se cadastrar ou confirmar seu usuário para acessar o conteúdo dessa página.";

	?>

	<img src="../img/face.png" class="face">
	<img src="../img/insta.png" class="insta">
	<img src="../img/zap.png" class="zap">
	<footer class="rodape">
		<p>© 2020 Seu Delivery - Todos os direitos reservados.</p>
	</footer>
</body>

</html>