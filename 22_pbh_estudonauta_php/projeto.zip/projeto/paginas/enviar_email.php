<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

$nome = $_GET['nome'];
$email = $_GET['email'];
$assunto = $_GET['assunto'];
$mensagem = $_GET['mensagem'];
$emailSeudelivery = 'seu email';

$mail = new PHPMailer;

$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'seu email';
$mail->Password = 'sua senha';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$mail->setFrom('seu email', 'Seu Delivery');


$mail->addAddress($emailSeudelivery);
$mail->isHTML(true);
$mail->Subject = 'Contato de Cliente';



$textoCorpo = '<h3>Nome do clinte: ' . $nome . '</h3>';
$textoCorpo .= '<p>Email do Cliente: ' . utf8_decode($email) . '</p>';
$textoCorpo .= '<p>Assunto: ' . utf8_decode($mensagem) . '</p>';
$textoCorpo .= '<p>Mensagem do Cliente: ' . utf8_decode($mensagem) . '</p>';
$mail->Body = $textoCorpo;

if (!$mail->send()) {
	echo 'Erro ao enviar email: ' . $mail->ErrorInfo;
} else {
	echo 'Mensagem Enviada.';
}
