<?php
session_start();
unset($_SESSION["usuario_verificado"]);
header('location: ../index.html');
