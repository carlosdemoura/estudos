<?php

require('conexaoBD.php');

$idSegura = $_GET['id'];

echo "<form action='#' method='post'>
       <input type='submit' value='Confirmar Inscrição' name='botao'>
      </form>";

if ((isset($_POST['botao'])) && (!empty($idSegura))) {
    $atualizar = ("UPDATE clientes SET confirma_cadastro = 1 WHERE md5(clienteID) = '$idSegura'");
    $insert = mysqli_query($conexao, $atualizar);
    if ($insert) {
        echo "Usuário Confirmado com Sucesso.";
        echo "<META HTTP-EQUIV='Refresh' CONTENT='3;URL=../index.html'>";
    }
}
