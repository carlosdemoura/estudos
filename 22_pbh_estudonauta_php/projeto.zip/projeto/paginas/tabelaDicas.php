<table class="tabela-temperaturas">
    <caption class="legenda-tabela">Temperatura ideal de Bebidas</caption>
    <tr class="titulo-tabela">
        <th>Cerveja</th>
        <th>Vinho</th>
        <th>Refrigerante</th>
    </tr>
    <tr>
        <td>0ºC a 4°C Cervejas sem álcool</td>
        <td>15ºC Vinho tinto</td>
        <td>Até 3º</td>
    </tr>
    <tr>
        <td>-5ºC a 7°C Cerveja de trigo claras e Pilsen</td>
        <td>10ºC e 12° Vinho Branco</td>
    </tr>
    <tr>
        <td>– 8ºC a 12°C Para Cervejas de trigo escuras</td>
    </tr>
</table>